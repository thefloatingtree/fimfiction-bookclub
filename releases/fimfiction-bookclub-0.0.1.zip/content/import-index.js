!function(){const n=JSON.parse('"content/index.js"');import(chrome.runtime.getURL(n));}();
